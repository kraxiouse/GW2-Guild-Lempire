export enum UserRole {
  SOLDAT = 'soldat',
  LIEUTENANT = 'lieutenant',
  GENERAL = 'general',
  EMPEREUR = 'empereur'
}

export interface User {
  id: string;
  username: string;
  role: UserRole;
  accessCode: string;
  avatarUrl?: string;
  joinDate: string;
  lastActive: string;
  gw2ApiKey?: string;
}

export interface ModerationAction {
  id: string;
  targetUserId: string;
  moderatorId: string;
  actionType: 'warn' | 'mute' | 'kick' | 'ban';
  reason: string;
  timestamp: string;
  duration?: string;
}

export interface Announcement {
  id: string;
  authorId: string;
  title: string;
  content: string;
  timestamp: string;
  important: boolean;
}

export interface GuildEvent {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  location: string;
  organizer: string;
  participants: string[];
}