import { db } from '../config/firebase';
import { collection, doc, getDocs, setDoc, updateDoc, deleteDoc, query, where, getDoc } from 'firebase/firestore';
import { User, ModerationAction, Announcement, GuildEvent } from '../types';

// Collections
const USERS = 'users';
const MODERATION_ACTIONS = 'moderationActions';
const ANNOUNCEMENTS = 'announcements';
const GUILD_EVENTS = 'guildEvents';

// User operations
export const getUsers = async (): Promise<User[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, USERS));
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
  } catch (error) {
    console.error('Error fetching users:', error);
    throw new Error('Failed to fetch users');
  }
};

export const getUserById = async (userId: string): Promise<User | null> => {
  try {
    const userDoc = await getDoc(doc(db, USERS, userId));
    if (userDoc.exists()) {
      return { id: userDoc.id, ...userDoc.data() } as User;
    }
    return null;
  } catch (error) {
    console.error('Error fetching user:', error);
    throw new Error('Failed to fetch user');
  }
};

export const updateUser = async (user: User): Promise<void> => {
  try {
    const userRef = doc(db, USERS, user.id);
    await updateDoc(userRef, { ...user });
  } catch (error) {
    console.error('Error updating user:', error);
    throw new Error('Failed to update user');
  }
};

export const createUser = async (user: User): Promise<void> => {
  try {
    const userRef = doc(db, USERS, user.id);
    await setDoc(userRef, user);
  } catch (error) {
    console.error('Error creating user:', error);
    throw new Error('Failed to create user');
  }
};

// Moderation actions operations
export const getModerationActions = async (): Promise<ModerationAction[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, MODERATION_ACTIONS));
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ModerationAction));
  } catch (error) {
    console.error('Error fetching moderation actions:', error);
    throw new Error('Failed to fetch moderation actions');
  }
};

export const createModerationAction = async (action: ModerationAction): Promise<void> => {
  try {
    const actionRef = doc(db, MODERATION_ACTIONS, action.id);
    await setDoc(actionRef, action);
  } catch (error) {
    console.error('Error creating moderation action:', error);
    throw new Error('Failed to create moderation action');
  }
};

// Announcements operations
export const getAnnouncements = async (): Promise<Announcement[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, ANNOUNCEMENTS));
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Announcement));
  } catch (error) {
    console.error('Error fetching announcements:', error);
    throw new Error('Failed to fetch announcements');
  }
};

export const createAnnouncement = async (announcement: Announcement): Promise<void> => {
  try {
    const announcementRef = doc(db, ANNOUNCEMENTS, announcement.id);
    await setDoc(announcementRef, announcement);
  } catch (error) {
    console.error('Error creating announcement:', error);
    throw new Error('Failed to create announcement');
  }
};

export const deleteAnnouncement = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, ANNOUNCEMENTS, id));
  } catch (error) {
    console.error('Error deleting announcement:', error);
    throw new Error('Failed to delete announcement');
  }
};

// Guild events operations
export const getGuildEvents = async (): Promise<GuildEvent[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, GUILD_EVENTS));
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GuildEvent));
  } catch (error) {
    console.error('Error fetching guild events:', error);
    throw new Error('Failed to fetch guild events');
  }
};

export const createGuildEvent = async (event: GuildEvent): Promise<void> => {
  try {
    const eventRef = doc(db, GUILD_EVENTS, event.id);
    await setDoc(eventRef, event);
  } catch (error) {
    console.error('Error creating guild event:', error);
    throw new Error('Failed to create guild event');
  }
};

export const updateGuildEvent = async (event: GuildEvent): Promise<void> => {
  try {
    const eventRef = doc(db, GUILD_EVENTS, event.id);
    await updateDoc(eventRef, { ...event });
  } catch (error) {
    console.error('Error updating guild event:', error);
    throw new Error('Failed to update guild event');
  }
};

export const deleteGuildEvent = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, GUILD_EVENTS, id));
  } catch (error) {
    console.error('Error deleting guild event:', error);
    throw new Error('Failed to delete guild event');
  }
};