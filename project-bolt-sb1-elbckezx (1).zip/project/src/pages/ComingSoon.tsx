import React from 'react';
import { Shield, Swords, Trophy, Users, MessageSquare, Settings, Calendar } from 'lucide-react';
import Card from '../components/common/Card';

interface Feature {
  title: string;
  description: string;
  icon: React.ReactNode;
  comingSoon: string;
}

interface ComingSoonProps {
  pageType: 'events' | 'messages' | 'settings';
}

const ComingSoon: React.FC<ComingSoonProps> = ({ pageType }) => {
  const features: Record<string, Feature[]> = {
    events: [
      {
        title: 'Événements récurrents',
        description: 'Créez des événements qui se répètent automatiquement selon un planning défini',
        icon: <Calendar className="w-8 h-8 text-amber-500" />,
        comingSoon: 'Juin 2024'
      },
      {
        title: 'Système de récompenses',
        description: 'Gagnez des points et des récompenses en participant aux événements de guilde',
        icon: <Trophy className="w-8 h-8 text-amber-500" />,
        comingSoon: 'Juillet 2024'
      },
      {
        title: 'Matchmaking PvP',
        description: 'Organisation automatique de matchs PvP équilibrés entre membres',
        icon: <Swords className="w-8 h-8 text-amber-500" />,
        comingSoon: 'Août 2024'
      }
    ],
    messages: [
      {
        title: 'Chat en temps réel',
        description: 'Discutez en direct avec les membres de la guilde',
        icon: <MessageSquare className="w-8 h-8 text-emerald-500" />,
        comingSoon: 'Juin 2024'
      },
      {
        title: 'Canaux thématiques',
        description: 'Créez des canaux dédiés pour différents sujets et activités',
        icon: <Users className="w-8 h-8 text-emerald-500" />,
        comingSoon: 'Juillet 2024'
      },
      {
        title: 'Système de mentions',
        description: 'Mentionnez des rôles ou des membres spécifiques dans vos messages',
        icon: <Shield className="w-8 h-8 text-emerald-500" />,
        comingSoon: 'Août 2024'
      }
    ],
    settings: [
      {
        title: 'Personnalisation avancée',
        description: 'Personnalisez l\'apparence et les notifications de l\'application',
        icon: <Settings className="w-8 h-8 text-blue-500" />,
        comingSoon: 'Juin 2024'
      },
      {
        title: 'Intégration Discord',
        description: 'Synchronisez vos activités avec votre serveur Discord',
        icon: <MessageSquare className="w-8 h-8 text-blue-500" />,
        comingSoon: 'Juillet 2024'
      },
      {
        title: 'Statistiques avancées',
        description: 'Suivez votre progression et celle de la guilde avec des graphiques détaillés',
        icon: <Trophy className="w-8 h-8 text-blue-500" />,
        comingSoon: 'Août 2024'
      }
    ]
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">
          {pageType === 'events' && 'Événements'}
          {pageType === 'messages' && 'Messages'}
          {pageType === 'settings' && 'Paramètres'}
        </h1>
      </div>

      <Card>
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold text-red-500 mb-2">Fonctionnalité à venir</h2>
          <p className="text-gray-600 mb-8">
            Cette section est en cours de développement. Voici ce qui vous attend :
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features[pageType].map((feature, index) => (
            <div
              key={index}
              className="bg-dark-800 rounded-lg p-6 transform transition-transform hover:scale-105"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-red-500 text-center mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-400 text-center mb-4">
                {feature.description}
              </p>
              <div className="text-center">
                <span className="inline-block bg-dark-700 text-red-400 px-3 py-1 rounded-full text-sm">
                  Disponible en {feature.comingSoon}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default ComingSoon;