import React from 'react';
import { useAuth } from '../context/AuthContext';
import Card from '../components/common/Card';
import { Announcement, GuildEvent, User, UserRole } from '../types';
import { getFromLocalStorage } from '../data/mockData';
import { Calendar, MessageCircle, Users } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const announcements = getFromLocalStorage<Announcement[]>('announcements', []);
  const events = getFromLocalStorage<GuildEvent[]>('guildEvents', []);
  const users = getFromLocalStorage<User[]>('users', []);
  
  // Filter to get recent events
  const upcomingEvents = events
    .filter(event => new Date(event.startTime) > new Date())
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())
    .slice(0, 3);
  
  // Get recent announcements
  const recentAnnouncements = [...announcements]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 3);
  
  // Find author usernames for announcements
  const findAuthorName = (authorId: string): string => {
    const author = users.find(u => u.id === authorId);
    return author ? author.username : 'Utilisateur inconnu';
  };
  
  // Format date for display
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Get statistics
  const totalMembers = users.length;
  const onlineMembers = 3; // Mock value - would be dynamic in a real app
  
  // Get role counts
  const roleCounts = users.reduce((acc, user) => {
    acc[user.role] = (acc[user.role] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
        <p className="text-sm text-gray-500">
          Bienvenue, <span className="font-medium">{currentUser?.username}</span>
        </p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-lg font-semibold">Membres</p>
              <p className="text-3xl font-bold">{totalMembers}</p>
            </div>
            <Users className="h-10 w-10 opacity-80" />
          </div>
          <div className="mt-4 text-blue-100">
            <p className="text-sm">
              {onlineMembers} membres en ligne
            </p>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-lg font-semibold">Événements</p>
              <p className="text-3xl font-bold">{upcomingEvents.length}</p>
            </div>
            <Calendar className="h-10 w-10 opacity-80" />
          </div>
          <div className="mt-4 text-amber-100">
            <p className="text-sm">
              {upcomingEvents.length > 0 
                ? `Prochain: ${upcomingEvents[0].title}` 
                : 'Aucun événement à venir'}
            </p>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-r from-emerald-500 to-green-600 text-white">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-lg font-semibold">Annonces</p>
              <p className="text-3xl font-bold">{announcements.length}</p>
            </div>
            <MessageCircle className="h-10 w-10 opacity-80" />
          </div>
          <div className="mt-4 text-emerald-100">
            <p className="text-sm">
              {recentAnnouncements.length > 0 
                ? `Dernière: ${recentAnnouncements[0].title}` 
                : 'Aucune annonce récente'}
            </p>
          </div>
        </Card>
      </div>
      
      {/* Role Distribution */}
      <Card title="Distribution des Rôles">
        <div className="flex flex-col space-y-4">
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className="bg-purple-600 h-4 rounded-full"
              style={{ width: `${(roleCounts[UserRole.EMPEREUR] || 0) / totalMembers * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-purple-800 font-medium">Empereur: {roleCounts[UserRole.EMPEREUR] || 0}</span>
            <span className="text-red-800 font-medium">Général: {roleCounts[UserRole.GENERAL] || 0}</span>
            <span className="text-blue-800 font-medium">Lieutenant: {roleCounts[UserRole.LIEUTENANT] || 0}</span>
            <span className="text-green-800 font-medium">Soldat: {roleCounts[UserRole.SOLDAT] || 0}</span>
          </div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Announcements */}
        <Card title="Annonces Récentes">
          {recentAnnouncements.length > 0 ? (
            <div className="space-y-4">
              {recentAnnouncements.map((announcement) => (
                <div key={announcement.id} className="border-b pb-4 last:border-0">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-gray-900">{announcement.title}</h4>
                    {announcement.important && (
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">
                        Important
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Par {findAuthorName(announcement.authorId)}</span>
                    <span>{formatDate(announcement.timestamp)}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">Aucune annonce récente</p>
          )}
        </Card>
        
        {/* Upcoming Events */}
        <Card title="Événements à Venir">
          {upcomingEvents.length > 0 ? (
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="border-b pb-4 last:border-0">
                  <h4 className="font-medium text-gray-900">{event.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                  <div className="mt-2 flex justify-between items-center">
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(event.startTime)}</span>
                    </div>
                    <div className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                      {event.location}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">Aucun événement à venir</p>
          )}
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;