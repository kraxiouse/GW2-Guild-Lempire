import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ModerationAction, User } from '../types';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { AlertTriangle, Shield } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { getModerationActions, createModerationAction, getUsers } from '../services/firestore';

const Moderation: React.FC = () => {
  const { hasModeratorRights, currentUser } = useAuth();
  const [actions, setActions] = useState<ModerationAction[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAction, setNewAction] = useState<{
    targetUserId: string;
    actionType: 'warn' | 'mute' | 'kick' | 'ban';
    reason: string;
    duration?: string;
  }>({
    targetUserId: '',
    actionType: 'warn',
    reason: '',
    duration: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [fetchedActions, fetchedUsers] = await Promise.all([
          getModerationActions(),
          getUsers()
        ]);
        setActions(fetchedActions.sort((a, b) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        ));
        setUsers(fetchedUsers);
      } catch (err) {
        setError('Erreur lors du chargement des données');
        console.error('Error fetching data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);
  
  if (!hasModeratorRights) {
    return <Navigate to="/dashboard" />;
  }
  
  const getUserById = (id: string): User | undefined => {
    return users.find(user => user.id === id);
  };
  
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleString('fr-FR');
  };
  
  const handleAddAction = async () => {
    if (!newAction.targetUserId || !newAction.reason) return;
    
    try {
      const newModerationAction: ModerationAction = {
        id: Date.now().toString(),
        targetUserId: newAction.targetUserId,
        moderatorId: currentUser?.id || '',
        actionType: newAction.actionType,
        reason: newAction.reason,
        timestamp: new Date().toISOString(),
        duration: newAction.actionType === 'mute' ? newAction.duration : undefined
      };
      
      await createModerationAction(newModerationAction);
      setActions([newModerationAction, ...actions]);
      setShowAddModal(false);
      setNewAction({
        targetUserId: '',
        actionType: 'warn',
        reason: '',
        duration: ''
      });
    } catch (err) {
      setError('Erreur lors de la création de l\'action de modération');
      console.error('Error creating moderation action:', err);
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-4">
        <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <p className="text-red-500">{error}</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Modération</h1>
        
        <Button 
          variant="primary"
          onClick={() => setShowAddModal(true)}
          className="flex items-center"
        >
          <Shield className="h-4 w-4 mr-2" />
          Nouvelle action de modération
        </Button>
      </div>
      
      <Card title="Historique des actions de modération">
        {actions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Action
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cible
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Modérateur
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Raison
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {actions.map((action) => {
                  const targetUser = getUserById(action.targetUserId);
                  const moderator = getUserById(action.moderatorId);
                  
                  return (
                    <tr key={action.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(action.timestamp)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          action.actionType === 'warn' ? 'bg-yellow-100 text-yellow-800' :
                          action.actionType === 'mute' ? 'bg-blue-100 text-blue-800' :
                          action.actionType === 'kick' ? 'bg-orange-100 text-orange-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {action.actionType === 'warn' ? 'Avertissement' :
                           action.actionType === 'mute' ? `Muet (${action.duration})` :
                           action.actionType === 'kick' ? 'Expulsion' :
                           'Bannissement'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {targetUser ? targetUser.username : 'Utilisateur inconnu'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {moderator ? moderator.username : 'Modérateur inconnu'}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {action.reason}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-6">
            <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">Aucune action de modération trouvée</p>
          </div>
        )}
      </Card>
      
      {/* Add Moderation Action Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Nouvelle action de modération</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Membre ciblé
                </label>
                <select
                  className="border-gray-300 rounded-md w-full"
                  value={newAction.targetUserId}
                  onChange={(e) => setNewAction({ ...newAction, targetUserId: e.target.value })}
                >
                  <option value="">Sélectionnez un membre</option>
                  {users
                    .filter(user => user.id !== currentUser?.id)
                    .map((user) => (
                      <option key={user.id} value={user.id}>
                        {user.username}
                      </option>
                    ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Type d'action
                </label>
                <select
                  className="border-gray-300 rounded-md w-full"
                  value={newAction.actionType}
                  onChange={(e) => setNewAction({ 
                    ...newAction, 
                    actionType: e.target.value as 'warn' | 'mute' | 'kick' | 'ban' 
                  })}
                >
                  <option value="warn">Avertissement</option>
                  <option value="mute">Muet</option>
                  <option value="kick">Expulsion</option>
                  <option value="ban">Bannissement</option>
                </select>
              </div>
              
              {newAction.actionType === 'mute' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Durée
                  </label>
                  <select
                    className="border-gray-300 rounded-md w-full"
                    value={newAction.duration}
                    onChange={(e) => setNewAction({ ...newAction, duration: e.target.value })}
                  >
                    <option value="">Sélectionnez une durée</option>
                    <option value="1h">1 heure</option>
                    <option value="12h">12 heures</option>
                    <option value="24h">24 heures</option>
                    <option value="48h">48 heures</option>
                    <option value="7j">7 jours</option>
                  </select>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Raison
                </label>
                <textarea
                  className="border-gray-300 rounded-md w-full"
                  rows={3}
                  value={newAction.reason}
                  onChange={(e) => setNewAction({ ...newAction, reason: e.target.value })}
                ></textarea>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <Button
                variant="secondary"
                onClick={() => setShowAddModal(false)}
              >
                Annuler
              </Button>
              <Button
                variant="primary"
                onClick={handleAddAction}
                disabled={!newAction.targetUserId || !newAction.reason || (newAction.actionType === 'mute' && !newAction.duration)}
              >
                Appliquer
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Moderation;