import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { GuildEvent, User, UserRole } from '../types';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { getFromLocalStorage, saveToLocalStorage } from '../data/mockData';
import { Calendar, Clock, MapPin, Plus, Users as UsersIcon } from 'lucide-react';

const Events: React.FC = () => {
  const { currentUser, hasModeratorRights } = useAuth();
  const [events, setEvents] = useState<GuildEvent[]>(
    getFromLocalStorage<GuildEvent[]>('guildEvents', [])
  );
  const [showAddModal, setShowAddModal] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<GuildEvent>>({
    title: '',
    description: '',
    startTime: '',
    endTime: '',
    location: '',
    participants: []
  });
  
  const users = getFromLocalStorage<User[]>('users', []);
  
  // Updated permission check to include Lieutenants
  const canManageEvents = [UserRole.EMPEREUR, UserRole.GENERAL, UserRole.LIEUTENANT].includes(currentUser?.role || UserRole.SOLDAT);

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.startTime || !newEvent.endTime) return;

    const newGuildEvent: GuildEvent = {
      id: Date.now().toString(),
      title: newEvent.title,
      description: newEvent.description || '',
      startTime: newEvent.startTime,
      endTime: newEvent.endTime,
      location: newEvent.location || '',
      organizer: currentUser?.id || '',
      participants: []
    };

    const updatedEvents = [...events, newGuildEvent];
    setEvents(updatedEvents);
    saveToLocalStorage('guildEvents', updatedEvents);
    setShowAddModal(false);
    setNewEvent({
      title: '',
      description: '',
      startTime: '',
      endTime: '',
      location: '',
      participants: []
    });
  };

  const handleJoinEvent = (eventId: string) => {
    if (!currentUser) return;

    const updatedEvents = events.map(event => {
      if (event.id === eventId) {
        const participants = event.participants.includes(currentUser.id)
          ? event.participants.filter(id => id !== currentUser.id)
          : [...event.participants, currentUser.id];
        return { ...event, participants };
      }
      return event;
    });

    setEvents(updatedEvents);
    saveToLocalStorage('guildEvents', updatedEvents);
  };

  const getParticipantNames = (participantIds: string[]): string[] => {
    return participantIds.map(id => {
      const user = users.find(u => u.id === id);
      return user ? user.username : 'Utilisateur inconnu';
    });
  };

  const getOrganizerName = (organizerId: string): string => {
    const organizer = users.find(u => u.id === organizerId);
    return organizer ? organizer.username : 'Organisateur inconnu';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Événements</h1>
        
        {canManageEvents && (
          <Button 
            variant="primary"
            onClick={() => setShowAddModal(true)}
            className="flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Créer un événement
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {events.map((event) => (
          <Card key={event.id} className="relative">
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-semibold text-gray-900">{event.title}</h3>
                {event.participants.includes(currentUser?.id || '') ? (
                  <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                    Inscrit
                  </span>
                ) : null}
              </div>

              <p className="text-gray-600">{event.description}</p>

              <div className="space-y-2 text-sm text-gray-500">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Début: {formatDate(event.startTime)}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Fin: {formatDate(event.endTime)}</span>
                </div>
                {event.location && (
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{event.location}</span>
                  </div>
                )}
                <div className="flex items-center">
                  <UsersIcon className="h-4 w-4 mr-2" />
                  <span>Organisateur: {getOrganizerName(event.organizer)}</span>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-2">Participants ({event.participants.length})</h4>
                <div className="flex flex-wrap gap-2">
                  {getParticipantNames(event.participants).map((name, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                    >
                      {name}
                    </span>
                  ))}
                </div>
              </div>

              <Button
                variant={event.participants.includes(currentUser?.id || '') ? 'secondary' : 'primary'}
                onClick={() => handleJoinEvent(event.id)}
                fullWidth
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                {event.participants.includes(currentUser?.id || '') ? 'Se désinscrire' : 'Participer'}
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {/* Add Event Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-800 rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4 text-red-500">Créer un nouvel événement</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Titre
                </label>
                <input
                  type="text"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Description
                </label>
                <textarea
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  rows={3}
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Date et heure de début
                </label>
                <input
                  type="datetime-local"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={newEvent.startTime}
                  onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Date et heure de fin
                </label>
                <input
                  type="datetime-local"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={newEvent.endTime}
                  onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Lieu
                </label>
                <input
                  type="text"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={newEvent.location}
                  onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <Button
                variant="secondary"
                onClick={() => setShowAddModal(false)}
                className="bg-dark-600 text-white hover:bg-dark-700"
              >
                Annuler
              </Button>
              <Button
                variant="primary"
                onClick={handleAddEvent}
                disabled={!newEvent.title || !newEvent.startTime || !newEvent.endTime}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Créer l'événement
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Events;