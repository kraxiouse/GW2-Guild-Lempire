import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { User } from '../types';
import { getFromLocalStorage, saveToLocalStorage } from '../data/mockData';
import { UserCog, Key } from 'lucide-react';

const Settings: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: currentUser?.username || '',
    accessCode: '',
    confirmAccessCode: '',
    gw2ApiKey: currentUser?.gw2ApiKey || '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const validateGW2ApiKey = async (apiKey: string): Promise<boolean> => {
    try {
      const response = await fetch(`https://api.guildwars2.com/v2/account`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`
        }
      });
      return response.ok;
    } catch (error) {
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (formData.accessCode && formData.accessCode !== formData.confirmAccessCode) {
      setError('Les codes d\'accès ne correspondent pas');
      return;
    }

    if (formData.gw2ApiKey && formData.gw2ApiKey !== currentUser?.gw2ApiKey) {
      const isValidApiKey = await validateGW2ApiKey(formData.gw2ApiKey);
      if (!isValidApiKey) {
        setError('Clé API GW2 invalide. Veuillez vérifier votre clé.');
        return;
      }
    }

    const users = getFromLocalStorage<User[]>('users', []);
    const updatedUsers = users.map(user => {
      if (user.id === currentUser?.id) {
        return {
          ...user,
          username: formData.username,
          gw2ApiKey: formData.gw2ApiKey,
          ...(formData.accessCode && { accessCode: formData.accessCode }),
        };
      }
      return user;
    });

    saveToLocalStorage('users', updatedUsers);
    
    const updatedCurrentUser = updatedUsers.find(user => user.id === currentUser?.id);
    if (updatedCurrentUser) {
      localStorage.setItem('currentUser', JSON.stringify(updatedCurrentUser));
    }

    setSuccess('Profil mis à jour avec succès');
    setIsEditing(false);
    
    if (formData.accessCode) {
      setTimeout(() => {
        logout();
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Paramètres du profil</h1>
      </div>

      <Card className="max-w-2xl">
        <div className="flex items-center space-x-4 mb-6">
          <div className="h-20 w-20 rounded-full bg-red-600 flex items-center justify-center text-white text-3xl font-bold">
            {currentUser?.username.charAt(0).toUpperCase()}
          </div>
          <div>
            <h2 className="text-xl font-semibold text-red-500">{currentUser?.username}</h2>
            <p className="text-gray-500">Membre depuis {new Date(currentUser?.joinDate || '').toLocaleDateString('fr-FR')}</p>
          </div>
        </div>

        {success && (
          <div className="mb-4 p-3 rounded bg-green-100 text-green-700">
            {success}
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 rounded bg-red-100 text-red-700">
            {error}
          </div>
        )}

        {isEditing ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Nom d'utilisateur
              </label>
              <input
                type="text"
                className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Clé API Guild Wars 2
              </label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={formData.gw2ApiKey}
                  onChange={(e) => setFormData({ ...formData, gw2ApiKey: e.target.value })}
                  placeholder="Entrez votre clé API GW2"
                />
                <a
                  href="https://account.arena.net/applications"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center px-3 py-2 bg-dark-600 text-white rounded-md hover:bg-dark-700"
                >
                  <Key className="w-4 h-4" />
                </a>
              </div>
              <p className="mt-1 text-xs text-gray-400">
                Créez une clé API avec les permissions "account" et "characters" sur le site officiel de GW2
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Nouveau code d'accès (optionnel)
              </label>
              <input
                type="password"
                className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                value={formData.accessCode}
                onChange={(e) => setFormData({ ...formData, accessCode: e.target.value })}
                placeholder="Laissez vide pour garder l'actuel"
              />
            </div>

            {formData.accessCode && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Confirmer le nouveau code d'accès
                </label>
                <input
                  type="password"
                  className="w-full bg-dark-700 border-dark-600 text-white rounded-md shadow-sm focus:ring-red-500 focus:border-red-500"
                  value={formData.confirmAccessCode}
                  onChange={(e) => setFormData({ ...formData, confirmAccessCode: e.target.value })}
                  required={!!formData.accessCode}
                />
              </div>
            )}

            <div className="flex space-x-3">
              <Button
                type="submit"
                variant="primary"
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Enregistrer
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsEditing(false)}
                className="bg-dark-600 text-white hover:bg-dark-700"
              >
                Annuler
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Nom d'utilisateur</p>
                <p className="text-lg text-white">{currentUser?.username}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Rôle</p>
                <p className="text-lg text-white capitalize">{currentUser?.role}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Date d'inscription</p>
                <p className="text-lg text-white">
                  {new Date(currentUser?.joinDate || '').toLocaleDateString('fr-FR')}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Dernière connexion</p>
                <p className="text-lg text-white">
                  {new Date(currentUser?.lastActive || '').toLocaleDateString('fr-FR')}
                </p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-gray-500">Clé API GW2</p>
                <p className="text-lg text-white">
                  {currentUser?.gw2ApiKey ? '••••••••••••••••' : 'Non configurée'}
                </p>
              </div>
            </div>

            <Button
              onClick={() => setIsEditing(true)}
              variant="primary"
              className="bg-red-600 hover:bg-red-700 text-white flex items-center"
            >
              <UserCog className="w-4 h-4 mr-2" />
              Modifier le profil
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Settings;