import React, { useState } from 'react';
import { getFromLocalStorage, saveToLocalStorage } from '../data/mockData';
import { User, UserRole } from '../types';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import Button from '../components/common/Button';
import { useAuth } from '../context/AuthContext';
import { ChevronDown, ChevronUp, Search, UserPlus } from 'lucide-react';

const MembersList: React.FC = () => {
  const [members, setMembers] = useState<User[]>(getFromLocalStorage<User[]>('users', []));
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof User>('username');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [showAddModal, setShowAddModal] = useState(false);
  
  const { currentUser, hasAdminRights } = useAuth();
  
  // New member form state
  const [newMember, setNewMember] = useState({
    username: '',
    role: UserRole.SOLDAT,
    accessCode: ''
  });
  
  // Filter members based on search term
  const filteredMembers = members.filter(member => 
    member.username.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Sort members
  const sortedMembers = [...filteredMembers].sort((a, b) => {
    if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1;
    if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });
  
  const handleSort = (field: keyof User) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  const getSortIcon = (field: keyof User) => {
    if (field !== sortField) return null;
    return sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />;
  };
  
  // Handle role change if user has admin rights
  const handleRoleChange = (userId: string, newRole: UserRole) => {
    if (!hasAdminRights) return;
    
    const updatedMembers = members.map(member => 
      member.id === userId ? { ...member, role: newRole } : member
    );
    
    setMembers(updatedMembers);
    saveToLocalStorage('users', updatedMembers);
  };
  
  // Get the display name for the role
  const getRoleDisplay = (role: UserRole) => {
    switch (role) {
      case UserRole.EMPEREUR:
        return 'Empereur';
      case UserRole.GENERAL:
        return 'Général';
      case UserRole.LIEUTENANT:
        return 'Lieutenant';
      case UserRole.SOLDAT:
        return 'Soldat';
      default:
        return role;
    }
  };
  
  // Format date
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('fr-FR');
  };
  
  // Handle adding a new member
  const handleAddMember = () => {
    if (!newMember.username || !newMember.accessCode) return;
    
    const newUser: User = {
      id: Date.now().toString(),
      username: newMember.username,
      role: newMember.role,
      accessCode: newMember.accessCode,
      joinDate: new Date().toISOString(),
      lastActive: new Date().toISOString()
    };
    
    const updatedMembers = [...members, newUser];
    setMembers(updatedMembers);
    saveToLocalStorage('users', updatedMembers);
    setShowAddModal(false);
    setNewMember({
      username: '',
      role: UserRole.SOLDAT,
      accessCode: ''
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Membres de la Guilde</h1>
        
        {hasAdminRights && (
          <Button 
            variant="primary"
            onClick={() => setShowAddModal(true)}
            className="flex items-center"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Ajouter un membre
          </Button>
        )}
      </div>
      
      <Card>
        <div className="mb-4 flex justify-between items-center">
          <div className="relative w-64">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5"
              placeholder="Rechercher un membre..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="text-sm text-gray-500">
            {filteredMembers.length} membre{filteredMembers.length !== 1 ? 's' : ''}
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('username')}
                >
                  <div className="flex items-center space-x-1">
                    <span>Nom d'utilisateur</span>
                    {getSortIcon('username')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('role')}
                >
                  <div className="flex items-center space-x-1">
                    <span>Rôle</span>
                    {getSortIcon('role')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('joinDate')}
                >
                  <div className="flex items-center space-x-1">
                    <span>Date d'entrée</span>
                    {getSortIcon('joinDate')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('lastActive')}
                >
                  <div className="flex items-center space-x-1">
                    <span>Dernière activité</span>
                    {getSortIcon('lastActive')}
                  </div>
                </th>
                {hasAdminRights && (
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedMembers.map((member) => (
                <tr key={member.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold mr-3">
                        {member.username.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{member.username}</div>
                        <div className="text-sm text-gray-500">ID: {member.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge label={getRoleDisplay(member.role)} role={member.role} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(member.joinDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(member.lastActive)}
                  </td>
                  {hasAdminRights && (
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {member.id !== currentUser?.id && (
                        <select
                          className="border-gray-300 rounded-md text-sm"
                          value={member.role}
                          onChange={(e) => handleRoleChange(member.id, e.target.value as UserRole)}
                        >
                          {Object.values(UserRole).map((role) => (
                            <option key={role} value={role}>
                              {getRoleDisplay(role)}
                            </option>
                          ))}
                        </select>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      {/* Add Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Ajouter un nouveau membre</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom d'utilisateur
                </label>
                <input
                  type="text"
                  className="border-gray-300 rounded-md w-full"
                  value={newMember.username}
                  onChange={(e) => setNewMember({ ...newMember, username: e.target.value })}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rôle
                </label>
                <select
                  className="border-gray-300 rounded-md w-full"
                  value={newMember.role}
                  onChange={(e) => setNewMember({ ...newMember, role: e.target.value as UserRole })}
                >
                  {Object.values(UserRole).map((role) => (
                    <option key={role} value={role}>
                      {getRoleDisplay(role)}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Code d'accès
                </label>
                <input
                  type="text"
                  className="border-gray-300 rounded-md w-full"
                  value={newMember.accessCode}
                  onChange={(e) => setNewMember({ ...newMember, accessCode: e.target.value })}
                />
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <Button
                variant="secondary"
                onClick={() => setShowAddModal(false)}
              >
                Annuler
              </Button>
              <Button
                variant="primary"
                onClick={handleAddMember}
                disabled={!newMember.username || !newMember.accessCode}
              >
                Ajouter
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MembersList;