import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Announcement, User, UserRole } from '../types';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { getFromLocalStorage, saveToLocalStorage } from '../data/mockData';
import { MessageSquare, Plus } from 'lucide-react';

const Messages: React.FC = () => {
  const { currentUser } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>(
    getFromLocalStorage<Announcement[]>('announcements', [])
  );
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAnnouncement, setNewAnnouncement] = useState({
    title: '',
    content: '',
    important: false
  });
  
  const users = getFromLocalStorage<User[]>('users', []);
  
  const canCreateAnnouncements = currentUser?.role === UserRole.EMPEREUR || 
                                currentUser?.role === UserRole.GENERAL;

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleAddAnnouncement = () => {
    if (!newAnnouncement.title || !newAnnouncement.content) return;

    const announcement: Announcement = {
      id: Date.now().toString(),
      authorId: currentUser?.id || '',
      title: newAnnouncement.title,
      content: newAnnouncement.content,
      timestamp: new Date().toISOString(),
      important: newAnnouncement.important
    };

    const updatedAnnouncements = [announcement, ...announcements];
    setAnnouncements(updatedAnnouncements);
    saveToLocalStorage('announcements', updatedAnnouncements);
    setShowAddModal(false);
    setNewAnnouncement({
      title: '',
      content: '',
      important: false
    });
  };

  const getAuthorName = (authorId: string): string => {
    const author = users.find(u => u.id === authorId);
    return author ? author.username : 'Auteur inconnu';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Messages & Annonces</h1>
        
        {canCreateAnnouncements && (
          <Button 
            variant="primary"
            onClick={() => setShowAddModal(true)}
            className="flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nouvelle annonce
          </Button>
        )}
      </div>

      <div className="space-y-6">
        {announcements.map((announcement) => (
          <Card key={announcement.id}>
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-semibold text-gray-900">{announcement.title}</h3>
                {announcement.important && (
                  <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                    Important
                  </span>
                )}
              </div>

              <p className="text-gray-600 whitespace-pre-wrap">{announcement.content}</p>

              <div className="flex justify-between items-center text-sm text-gray-500">
                <div className="flex items-center">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  <span>Par {getAuthorName(announcement.authorId)}</span>
                </div>
                <span>{formatDate(announcement.timestamp)}</span>
              </div>
            </div>
          </Card>
        ))}

        {announcements.length === 0 && (
          <Card>
            <div className="text-center py-6">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">Aucune annonce pour le moment</p>
            </div>
          </Card>
        )}
      </div>

      {/* Add Announcement Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Nouvelle annonce</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Titre
                </label>
                <input
                  type="text"
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500"
                  value={newAnnouncement.title}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contenu
                </label>
                <textarea
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500"
                  rows={5}
                  value={newAnnouncement.content}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })}
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="important"
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  checked={newAnnouncement.important}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, important: e.target.checked })}
                />
                <label htmlFor="important" className="ml-2 text-sm text-gray-700">
                  Marquer comme important
                </label>
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <Button
                variant="secondary"
                onClick={() => setShowAddModal(false)}
              >
                Annuler
              </Button>
              <Button
                variant="primary"
                onClick={handleAddAnnouncement}
                disabled={!newAnnouncement.title || !newAnnouncement.content}
              >
                Publier
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Messages;