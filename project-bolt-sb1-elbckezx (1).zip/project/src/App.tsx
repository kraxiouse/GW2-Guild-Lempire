import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './components/Login';
import Register from './components/Register';
import MainLayout from './components/Layout/MainLayout';
import Dashboard from './pages/Dashboard';
import MembersList from './pages/MembersList';
import Moderation from './pages/Moderation';
import ComingSoon from './pages/ComingSoon';

const AppRoutes: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/dashboard" />} />
      <Route path="/register" element={!isAuthenticated ? <Register /> : <Navigate to="/dashboard" />} />
      <Route path="/dashboard" element={<MainLayout><Dashboard /></MainLayout>} />
      <Route path="/members" element={<MainLayout><MembersList /></MainLayout>} />
      <Route path="/events" element={<MainLayout><ComingSoon pageType="events" /></MainLayout>} />
      <Route path="/messages" element={<MainLayout><ComingSoon pageType="messages" /></MainLayout>} />
      <Route path="/moderation" element={<MainLayout><Moderation /></MainLayout>} />
      <Route path="/settings" element={<MainLayout><ComingSoon pageType="settings" /></MainLayout>} />
      <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} />} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;