import { Announcement, GuildEvent, ModerationAction, User, UserRole } from '../types';

export const users: User[] = [
  {
    id: '1',
    username: 'EmpereurSupreme',
    role: UserRole.EMPEREUR,
    accessCode: 'emp123',
    avatarUrl: 'https://images.pexels.com/photos/1172253/pexels-photo-1172253.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    joinDate: '2022-01-15',
    lastActive: '2023-10-01',
    gw2ApiKey: '',
  },
  {
    id: '2',
    username: 'GeneralValiant',
    role: UserRole.GENERAL,
    accessCode: 'gen456',
    avatarUrl: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    joinDate: '2022-02-20',
    lastActive: '2023-09-28',
    gw2ApiKey: '',
  },
  {
    id: '3',
    username: 'LieutenantBrave',
    role: UserRole.LIEUTENANT,
    accessCode: 'lt789',
    avatarUrl: 'https://images.pexels.com/photos/2787341/pexels-photo-2787341.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    joinDate: '2022-03-10',
    lastActive: '2023-09-30',
    gw2ApiKey: '',
  },
  {
    id: '4',
    username: 'SoldatFidele',
    role: UserRole.SOLDAT,
    accessCode: 'sol123',
    avatarUrl: 'https://images.pexels.com/photos/1552617/pexels-photo-1552617.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    joinDate: '2022-04-05',
    lastActive: '2023-09-25',
    gw2ApiKey: '',
  },
  {
    id: '5',
    username: 'SoldatNouvel',
    role: UserRole.SOLDAT,
    accessCode: 'sol456',
    avatarUrl: 'https://images.pexels.com/photos/1121796/pexels-photo-1121796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    joinDate: '2023-01-22',
    lastActive: '2023-09-29',
    gw2ApiKey: '',
  },
];

export const moderationActions: ModerationAction[] = [
  {
    id: '1',
    targetUserId: '5',
    moderatorId: '2',
    actionType: 'warn',
    reason: 'Comportement inapproprié dans le chat',
    timestamp: '2023-09-20T15:30:00',
  },
  {
    id: '2',
    targetUserId: '4',
    moderatorId: '1',
    actionType: 'mute',
    reason: 'Spam dans le chat de guilde',
    timestamp: '2023-09-15T10:45:00',
    duration: '24h',
  },
];

export const announcements: Announcement[] = [
  {
    id: '1',
    authorId: '1',
    title: 'Bienvenue dans notre nouvelle application de guilde!',
    content: 'Nous sommes heureux de lancer notre nouvelle application pour mieux organiser notre guilde dans Guild Wars 2. Explorez les fonctionnalités et faites-nous part de vos commentaires.',
    timestamp: '2023-10-01T09:00:00',
    important: true,
  },
  {
    id: '2',
    authorId: '2',
    title: 'Événement de raid ce weekend',
    content: 'Nous organisons un raid ce samedi à 20h. Tous les membres sont invités à participer. Préparez votre équipement!',
    timestamp: '2023-09-28T17:30:00',
    important: false,
  },
];

export const guildEvents: GuildEvent[] = [
  {
    id: '1',
    title: 'Raid Hebdomadaire',
    description: 'Notre raid hebdomadaire pour obtenir des récompenses légendaires.',
    startTime: '2023-10-07T20:00:00',
    endTime: '2023-10-07T23:00:00',
    location: 'Forteresse des Fidèles',
    organizer: '2',
    participants: ['1', '2', '3', '4'],
  },
  {
    id: '2',
    title: 'Formation PvP',
    description: 'Session d\'entraînement pour améliorer nos compétences en PvP.',
    startTime: '2023-10-05T19:00:00',
    endTime: '2023-10-05T21:00:00',
    location: 'Brumes',
    organizer: '3',
    participants: ['3', '4', '5'],
  },
];

export const saveToLocalStorage = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to localStorage: ${error}`);
  }
};

export const getFromLocalStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const storedData = localStorage.getItem(key);
    return storedData ? JSON.parse(storedData) : defaultValue;
  } catch (error) {
    console.error(`Error retrieving from localStorage: ${error}`);
    return defaultValue;
  }
};

export const initializeLocalStorage = (): void => {
  if (!localStorage.getItem('users')) {
    saveToLocalStorage('users', users);
  }
  if (!localStorage.getItem('moderationActions')) {
    saveToLocalStorage('moderationActions', moderationActions);
  }
  if (!localStorage.getItem('announcements')) {
    saveToLocalStorage('announcements', announcements);
  }
  if (!localStorage.getItem('guildEvents')) {
    saveToLocalStorage('guildEvents', guildEvents);
  }
};