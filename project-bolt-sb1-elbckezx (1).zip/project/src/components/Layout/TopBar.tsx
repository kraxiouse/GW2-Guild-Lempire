import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Bell, Menu, X } from 'lucide-react';
import Sidebar from './Sidebar';

const TopBar: React.FC = () => {
  const { currentUser } = useAuth();
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [notifications, setNotifications] = useState<{id: string, text: string}[]>([
    { id: '1', text: 'Nouvel événement ce weekend!' },
    { id: '2', text: 'Vous avez 3 nouveaux messages' }
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  
  const toggleMobileMenu = () => {
    setShowMobileMenu(!showMobileMenu);
  };
  
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };
  
  const dismissNotification = (id: string) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  return (
    <>
      <header className="bg-dark-900 shadow h-16 flex items-center px-4 md:px-6">
        <button
          className="md:hidden mr-2"
          onClick={toggleMobileMenu}
        >
          <Menu className="h-6 w-6 text-gray-500" />
        </button>
        
        <div className="flex-1 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-red-500">
            Guild Wars 2 - Gestion de Guilde
          </h1>
          
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative">
              <button
                className="relative p-1 rounded-full text-gray-400 hover:text-red-500 focus:outline-none focus:ring-2 focus:ring-red-500"
                onClick={toggleNotifications}
              >
                <Bell className="h-6 w-6" />
                {notifications.length > 0 && (
                  <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </button>
              
              {/* Notifications dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-dark-800 rounded-md shadow-lg py-1 z-10 border border-dark-700">
                  <div className="px-4 py-2 text-sm font-medium text-red-500 border-b border-dark-700">
                    Notifications
                  </div>
                  
                  {notifications.length === 0 ? (
                    <div className="px-4 py-3 text-sm text-gray-400">
                      Pas de nouvelles notifications
                    </div>
                  ) : (
                    <div>
                      {notifications.map((notification) => (
                        <div 
                          key={notification.id}
                          className="px-4 py-3 hover:bg-dark-700 flex justify-between items-center"
                        >
                          <span className="text-sm text-gray-300">{notification.text}</span>
                          <button
                            onClick={() => dismissNotification(notification.id)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* User profile */}
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-full bg-red-600 flex items-center justify-center text-white">
                {currentUser?.username.charAt(0).toUpperCase()}
              </div>
              <span className="ml-2 text-sm font-medium text-red-500 hidden md:block">
                {currentUser?.username}
              </span>
            </div>
          </div>
        </div>
      </header>
      
      {/* Mobile sidebar */}
      {showMobileMenu && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-75" onClick={toggleMobileMenu}></div>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-dark-900">
            <div className="absolute top-0 right-0 -mr-12 pt-2">
              <button
                className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                onClick={toggleMobileMenu}
              >
                <X className="h-6 w-6 text-white" />
              </button>
            </div>
            <Sidebar />
          </div>
        </div>
      )}
    </>
  );
};

export default TopBar;