import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import { 
  Home, 
  Users, 
  Calendar, 
  MessageSquare, 
  ShieldAlert, 
  Settings,
  LogOut
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const { currentUser, logout, hasModeratorRights } = useAuth();
  const location = useLocation();
  
  if (!currentUser) return null;
  
  const navItems = [
    { 
      name: 'Tableau de bord', 
      path: '/dashboard', 
      icon: <Home className="w-5 h-5" /> 
    },
    { 
      name: 'Membres', 
      path: '/members', 
      icon: <Users className="w-5 h-5" /> 
    },
    { 
      name: 'Événements', 
      path: '/events', 
      icon: <Calendar className="w-5 h-5" /> 
    },
    { 
      name: 'Messages', 
      path: '/messages', 
      icon: <MessageSquare className="w-5 h-5" /> 
    }
  ];
  
  if (hasModeratorRights) {
    navItems.push({ 
      name: 'Modération', 
      path: '/moderation', 
      icon: <ShieldAlert className="w-5 h-5" /> 
    });
  }
  
  navItems.push({ 
    name: 'Paramètres', 
    path: '/settings', 
    icon: <Settings className="w-5 h-5" /> 
  });
  
  const isActive = (path: string) => location.pathname === path;
  
  const getRoleDisplay = (role: UserRole) => {
    switch (role) {
      case UserRole.EMPEREUR:
        return 'Empereur';
      case UserRole.GENERAL:
        return 'Général';
      case UserRole.LIEUTENANT:
        return 'Lieutenant';
      case UserRole.SOLDAT:
        return 'Soldat';
      default:
        return role;
    }
  };

  return (
    <div className="bg-dark-900 text-white w-64 min-h-screen flex flex-col">
      <div className="p-4 border-b border-dark-700">
        <h2 className="text-xl font-bold text-center text-red-500">GW2 Gestion de Guilde</h2>
      </div>
      
      <div className="p-4 border-b border-dark-700">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-red-600 flex items-center justify-center text-white font-bold">
            {currentUser.username.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="font-medium text-red-500">{currentUser.username}</p>
            <p className="text-xs text-gray-400">{getRoleDisplay(currentUser.role)}</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 py-4">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center space-x-3 px-4 py-2 ${
                  isActive(item.path)
                    ? 'bg-red-900 text-white'
                    : 'text-gray-300 hover:bg-red-900/50 hover:text-white'
                }`}
              >
                {item.icon}
                <span>{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-dark-700">
        <button
          onClick={logout}
          className="flex items-center space-x-2 text-gray-300 hover:text-red-500 w-full"
        >
          <LogOut className="w-5 h-5" />
          <span>Déconnexion</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;