import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield } from 'lucide-react';
import Button from './common/Button';
import Card from './common/Card';
import { registerUser } from '../config/firebase';
import { createUser } from '../services/firestore';
import { User, UserRole } from '../types';

const Register: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    username: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      setIsLoading(false);
      return;
    }

    try {
      const firebaseUser = await registerUser(formData.email, formData.password);
      
      const newUser: User = {
        id: firebaseUser.uid,
        username: formData.username,
        role: UserRole.SOLDAT,
        accessCode: '',
        joinDate: new Date().toISOString(),
        lastActive: new Date().toISOString(),
        gw2ApiKey: ''
      };

      await createUser(newUser);
      navigate('/login');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-900 bg-[url('https://images.pexels.com/photos/1072179/pexels-photo-1072179.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center">
      <div className="w-full max-w-md px-4">
        <Card variant="fancy" className="backdrop-blur-sm bg-dark-800/90">
          <div className="flex flex-col items-center mb-6">
            <div className="bg-red-900/50 p-3 rounded-full mb-4">
              <Shield className="h-8 w-8 text-red-500" />
            </div>
            <h2 className="text-center text-2xl font-bold text-red-500 mt-2">
              Créer un compte
            </h2>
            <p className="text-center text-gray-400 mt-1">
              Rejoignez la guilde GW2
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded bg-red-900/50 text-red-200 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-300">
                Nom d'utilisateur
              </label>
              <input
                id="username"
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                Mot de passe
              </label>
              <input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-300">
                Confirmer le mot de passe
              </label>
              <input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>

            <Button
              type="submit"
              fullWidth
              disabled={isLoading}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-500"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Création en cours...
                </div>
              ) : (
                'Créer un compte'
              )}
            </Button>

            <div className="text-center mt-4">
              <p className="text-sm text-gray-400">
                Déjà un compte?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="text-red-500 hover:text-red-400"
                >
                  Se connecter
                </button>
              </p>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Register;