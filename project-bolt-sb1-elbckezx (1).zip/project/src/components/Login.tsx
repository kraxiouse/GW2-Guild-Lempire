import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Button from './common/Button';
import Card from './common/Card';
import { Shield } from 'lucide-react';
import { loginUser } from '../config/firebase';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const firebaseUser = await loginUser(formData.email, formData.password);
      const success = await login(firebaseUser.uid);
      
      if (!success) {
        setError('Erreur lors de la connexion. Veuillez réessayer.');
      }
    } catch (err: any) {
      setError('Email ou mot de passe incorrect');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-900 bg-[url('https://images.pexels.com/photos/1072179/pexels-photo-1072179.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center">
      <div className="w-full max-w-md px-4">
        <Card variant="fancy" className="backdrop-blur-sm bg-dark-800/90">
          <div className="flex flex-col items-center mb-6">
            <div className="bg-red-900/50 p-3 rounded-full mb-4">
              <Shield className="h-8 w-8 text-red-500" />
            </div>
            <h2 className="text-center text-2xl font-bold text-red-500 mt-2">
              Connexion
            </h2>
            <p className="text-center text-gray-400 mt-1">
              Connectez-vous à votre compte
            </p>
          </div>
          
          {error && (
            <div className="mb-4 p-3 rounded bg-red-900/50 text-red-200 text-sm">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                Mot de passe
              </label>
              <input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="mt-1 block w-full rounded-md bg-dark-700 border-dark-600 text-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 sm:text-sm p-2"
                required
              />
            </div>
            
            <Button
              type="submit"
              fullWidth
              disabled={isLoading}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-500"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Connexion en cours...
                </div>
              ) : (
                'Se connecter'
              )}
            </Button>

            <div className="text-center mt-4">
              <p className="text-sm text-gray-400">
                Pas encore de compte?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/register')}
                  className="text-red-500 hover:text-red-400"
                >
                  Créer un compte
                </button>
              </p>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Login;