import React from 'react';
import { UserRole } from '../../types';

interface BadgeProps {
  label: string;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'role';
  role?: UserRole;
}

const Badge: React.FC<BadgeProps> = ({ 
  label, 
  variant = 'default',
  role
}) => {
  const baseStyles = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium';
  
  let variantStyles = '';
  
  if (variant === 'role' && role) {
    switch (role) {
      case UserRole.EMPEREUR:
        variantStyles = 'bg-purple-100 text-purple-800 border border-purple-400';
        break;
      case UserRole.GENERAL:
        variantStyles = 'bg-red-100 text-red-800 border border-red-400';
        break;
      case UserRole.LIEUTENANT:
        variantStyles = 'bg-blue-100 text-blue-800 border border-blue-400';
        break;
      case UserRole.SOLDAT:
        variantStyles = 'bg-green-100 text-green-800 border border-green-400';
        break;
      default:
        variantStyles = 'bg-gray-100 text-gray-800 border border-gray-400';
    }
  } else {
    switch (variant) {
      case 'success':
        variantStyles = 'bg-green-100 text-green-800';
        break;
      case 'warning':
        variantStyles = 'bg-yellow-100 text-yellow-800';
        break;
      case 'danger':
        variantStyles = 'bg-red-100 text-red-800';
        break;
      default:
        variantStyles = 'bg-gray-100 text-gray-800';
    }
  }
  
  return (
    <span className={`${baseStyles} ${variantStyles}`}>
      {label}
    </span>
  );
};

export default Badge;