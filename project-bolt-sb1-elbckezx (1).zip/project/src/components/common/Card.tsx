import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  title?: string;
  variant?: 'default' | 'bordered' | 'fancy';
  className?: string;
}

const Card: React.FC<CardProps> = ({ 
  children, 
  title, 
  variant = 'default', 
  className = '' 
}) => {
  const baseStyles = 'bg-white rounded-lg shadow';
  
  const variantStyles = {
    default: '',
    bordered: 'border-2 border-gray-200',
    fancy: 'border-2 border-amber-500 bg-gradient-to-br from-white to-amber-50'
  };
  
  return (
    <div className={`${baseStyles} ${variantStyles[variant]} ${className}`}>
      {title && (
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">{title}</h3>
        </div>
      )}
      <div className="p-6">{children}</div>
    </div>
  );
};

export default Card;