import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';
import { getUsers, updateUser } from '../services/firestore';

interface AuthContextType {
  currentUser: User | null;
  login: (accessCode: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  hasModeratorRights: boolean;
  hasAdminRights: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check for saved user session
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setCurrentUser(parsedUser);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Failed to parse saved user:', error);
        localStorage.removeItem('currentUser');
      }
    }
  }, []);

  const login = async (accessCode: string): Promise<boolean> => {
    try {
      const users = await getUsers();
      const user = users.find(u => u.accessCode === accessCode);
      
      if (user) {
        setCurrentUser(user);
        setIsAuthenticated(true);
        
        // Update last active timestamp
        const updatedUser = { ...user, lastActive: new Date().toISOString() };
        await updateUser(updatedUser);
        
        // Save current user to local storage for session persistence
        localStorage.setItem('currentUser', JSON.stringify(updatedUser));
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  const hasModeratorRights = currentUser 
    ? [UserRole.LIEUTENANT, UserRole.GENERAL, UserRole.EMPEREUR].includes(currentUser.role) 
    : false;

  const hasAdminRights = currentUser 
    ? [UserRole.GENERAL, UserRole.EMPEREUR].includes(currentUser.role) 
    : false;

  const value = {
    currentUser,
    login,
    logout,
    isAuthenticated,
    hasModeratorRights,
    hasAdminRights,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};